export declare function observeProps(props: any): void;
